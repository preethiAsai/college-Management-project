package com.example.College;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollegeApplicationTests {

	@Test
	void contextLoads() {
	}

}
