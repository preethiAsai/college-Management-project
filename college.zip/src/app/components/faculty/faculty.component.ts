import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-faculty',
  templateUrl: './faculty.component.html',
  styleUrls: ['./faculty.component.css']
})
export class FacultyComponent {FacultyArray:any[]=[];
  isResultLoaded=false;
  isUpdateFormActive=false;
  name:string="";
  experience:string="";
  mobile:Number=0;
  email:string="";
  department:string="";
  currentFacultyID="";
  constructor(private http:HttpClient)
  {
    this.getAllFaculty();
  }
  getAllFaculty() : void
  {
    this.http.get("http://localhost:9090/api/v1/faculty/getAllFacultys")
    .subscribe((resultData: any)=>
      {
          this.isResultLoaded = true;
          console.log(resultData);
          this.FacultyArray = resultData;
      });
  }
  register()
  {
    let bodyData={
      "name":this.name,"experience":this.experience,"mobile":this.mobile,"email":this.email,"department":this.department
    };
    this.http.post("http://localhost:9090/api/v1/faculty/save",bodyData,{responseType:'text'}).subscribe((resultData: any)=>
    {
  console.log(resultData);
  alert("Faculty registered successfully");
  this.getAllFaculty();
  this.name="";
  this.experience="";
  this.mobile=0;
  this.email="";
  this.department="";
    });
  }
  setUpdate(data:any)
  {
    this.name=data.name;
    this.experience=data.experience;
    this.mobile=data.mobile;
    this.email=data.email;
    this.department=data.department;
    this.currentFacultyID=data.currentFacultyID;
  }
  save()
    {
      if(this.currentFacultyID == " ")
      {
          this.register();
      }
        else 
        {
         this.updateRecords();
        }      
    }
  
  updateRecords()
  {
    let bodyData={
      "facultyid":this.currentFacultyID,"name":this.name,"experience":this.experience,"mobile":this.mobile,"email":this.email,"department":this.department
    };
    this.http.put("http://localhost:9090/api/v1/faculty/update/id",bodyData,{responseType: 'text'}).subscribe((resultData: any)=>
  {
    console.log(resultData);
    alert("Details updated successfully");
    this.getAllFaculty();
    this.name="";
    this.experience="";
    this.mobile=0;
    this.email="";
    this.department="";
  });
  }
    setDelete(data: any)
    {
      
      
      this.http.delete("http://localhost:9090/api/v1/faculty/deleteFaculty"+ "/"+ data.facultyid,{responseType: 'text'}).subscribe((resultData: any)=>
      {
          console.log(resultData);
          alert("Faculty Deleted")
          this.getAllFaculty();
          this.name="";
          this.experience="";
          this.mobile=0;
          this.email="";
          this.department="";      });
      }
    
    }

